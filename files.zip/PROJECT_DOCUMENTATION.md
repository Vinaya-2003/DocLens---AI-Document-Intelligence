# DocLens — Project Documentation

## 1. What is DocLens?

DocLens is an AI powered document intelligence web application.
You upload any PDF document, and it lets you ask questions about
it in plain English. The app finds the relevant parts of your
document and gives you accurate answers in seconds.

It is built using a technique called RAG — Retrieval Augmented
Generation — which is one of the most widely used AI patterns
in production systems today.

---

## 2. The Problem it Solves

Reading long PDF documents to find one specific piece of
information is slow and frustrating. A 200 page annual report
might contain one paragraph that answers your question.
Without DocLens you would have to read all 200 pages or use
Ctrl+F which only finds exact keywords.

DocLens understands the MEANING of your question and finds
relevant sections even if the exact words do not match.

Example:
You ask:         "How did the company perform financially?"
Document says:   "Revenue grew 12% to reach 450 crore in FY2024"
DocLens finds:   This section — even though your question
                 did not contain the words revenue or crore.

---

## 3. How I Built This — Step by Step

### Step 1 — PDF Loading
When a user uploads a PDF the app reads every page using
PyPDFLoader from LangChain. Each page is converted into text.

### Step 2 — Chunking
The full text is split into chunks of 1000 characters with
200 characters of overlap between neighbouring chunks.

Why chunking?
AI models can only read a limited amount of text at once.
Smaller chunks make search faster and more accurate.
Overlap prevents losing information at chunk boundaries.

### Step 3 — Embeddings
Each chunk is converted into a vector of 384 numbers using
the HuggingFace model sentence-transformers/all-MiniLM-L6-v2.
Similar sentences get similar vectors.
This is called semantic search — search by meaning not keywords.

### Step 4 — Vector Store
All vectors are stored in FAISS (Facebook AI Similarity Search).
FAISS can search through millions of vectors in milliseconds.

### Step 5 — Question Answering
When the user asks a question:
1. The question is converted into a vector
2. FAISS finds the 4 most similar chunks
3. Those 4 chunks are sent to Groq LLaMA along with the question
4. LLaMA reads the chunks and writes an accurate answer
5. The answer is shown with a confidence score and source sections

### Step 6 — Confidence Scoring
The FAISS similarity distance is converted to a percentage.
High = document clearly contains this information
Medium = document partially covers this topic
Low = information may not be in the document
This is the key feature that no other free PDF tool provides.

---

## 4. Tools and Libraries

### Python 3.12
The entire application is written in Python.

### LangChain
Open source framework that connects AI models with data.
Used to build the RAG pipeline connecting retriever and LLM.

### FAISS
Facebook AI Similarity Search.
Stores document vectors and searches them at high speed.

### HuggingFace Sentence Transformers
Free library of pre-trained embedding models.
Model used: sentence-transformers/all-MiniLM-L6-v2
Converts text into 384 dimensional vectors.

### Groq API
Free API giving access to LLaMA 3.3 70B language model.
Generates answers from retrieved document chunks.

### Streamlit
Python library that creates interactive web apps.
No HTML CSS or JavaScript knowledge needed.
Used to build the entire user interface.

### PyPDF
Python library for reading PDF files.
Extracts text from every page of uploaded documents.

### Python Dotenv
Loads secret API keys from .env file.
Keeps credentials out of the code.

---

## 5. Features Built

### Multi PDF Support
Upload multiple PDFs at once. All documents are combined
into one vector store. Questions can span all documents.
This fills the gap in ChatPDF which only supports one PDF.

### Confidence Scoring
Every answer shows how relevant the retrieved chunks are.
No other free PDF chat tool provides answer verification.

### Auto Summary
Document is summarised immediately on upload.
Users understand the document before asking any questions.

### Source Transparency
Every answer shows which exact sections were used.
Users can verify any answer against the original text.

### Download Q&A History
Complete session exported as a text file on demand.
Free tools like ChatPDF do not offer this.

### Data Privacy
PDF deleted immediately after processing.
No permanent storage of any user data.
Auto session expiry after 30 minutes.
Manual clear session button available.

---

## 6. Architecture

```
User uploads PDF
      ↓
PyPDF reads all pages
      ↓
RecursiveCharacterTextSplitter
cuts into 1000 character chunks with 200 overlap
      ↓
HuggingFace all-MiniLM-L6-v2
converts chunks to 384 dimensional vectors
      ↓
FAISS stores all vectors in memory
      ↓
PDF deleted from server immediately
      ↓
User types a question
      ↓
Question converted to vector
      ↓
FAISS finds 4 most similar chunk vectors
      ↓
4 chunks + question sent to Groq LLaMA 3.3 70B
      ↓
LLaMA generates answer using only those 4 chunks
      ↓
FAISS distance converted to confidence percentage
      ↓
Answer + confidence label + source chunks shown to user
```

---

## 7. What Makes DocLens Different From Existing Tools

All existing PDF chat tools like ChatPDF and AskYourPDF:
- Only support one PDF at a time
- Give no indication of answer reliability
- Show no source transparency
- Restrict free usage with daily limits
- Are vague about data privacy

DocLens addresses every single one of these gaps.

---

## 8. Project Specifications

App name:         DocLens
Tagline:          See inside any document. Instantly.
Type:             AI document intelligence web app
Version:          1.0.0
Author:           Vinaya K
Built:            March 2026
License:          All Rights Reserved

Chunk size:       1000 characters
Chunk overlap:    200 characters
Chunks retrieved: 4 per query
LLM temperature:  0 (factual mode)
Max response:     1024 tokens
Session timeout:  30 minutes
Max file size:    10MB per PDF
Embedding dims:   384

---

## 9. Files in This Project

app.py                    Web interface built with Streamlit
rag_pipeline.py           All AI logic — RAG pipeline
requirements.txt          Python libraries needed
.env                      Secret API keys (never on GitHub)
.gitignore                Files excluded from GitHub
.streamlit/secrets.toml   Streamlit Cloud secret keys
LICENSE                   Copyright protection
README.md                 GitHub project overview
PROJECT_DOCUMENTATION.md  This detailed explanation file

---

## 10. Author

Vinaya K
Data Scientist and ML Engineer
Email: vinayakallivalappil@gmail.com
Location: Palakkad, Kerala, India
